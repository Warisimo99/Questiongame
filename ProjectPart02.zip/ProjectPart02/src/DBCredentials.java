
public class DBCredentials {
	protected static String username = "javauser";
	protected static String password = "password";
}
